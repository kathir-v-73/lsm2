/**
 * Prime Vector LSM Portal – Landing Page JavaScript
 * landing.js
 */

document.addEventListener('DOMContentLoaded', function () {
  // Smooth reveal animations for sections as user scrolls
  const revealElements = document.querySelectorAll('.login-card, .course-card-landing, .stats-banner-item');

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealElements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    revealObserver.observe(el);
  });
});
