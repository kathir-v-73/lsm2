"""
Prime Vector LSM Portal – Mentor Routes
All protected routes for the mentor dashboard.
"""

from flask import Blueprint, render_template, session, jsonify, request
from pathlib import Path
from utils.data_manager import DataManager
from routes.auth import mentor_required

mentor_bp = Blueprint("mentor", __name__, url_prefix="/mentor")

_BASE = Path(__file__).resolve().parent.parent
dm = DataManager(_BASE / "data")


@mentor_bp.route("/dashboard")
@mentor_required
def dashboard():
    """Main mentor dashboard – loads all relevant mentor data."""
    user_id = session.get("user_id")

    # Mentor profile
    mentor = dm.get_by_id("mentors", user_id)
    if not mentor:
        return "Mentor not found", 404

    # Assigned students
    all_students = dm.get_all("students")
    assigned_ids = mentor.get("students_assigned", [])
    my_students = [s for s in all_students if s["id"] in assigned_ids]

    # Assigned courses
    all_courses = dm.get_all("courses")
    course_ids = mentor.get("courses_assigned", [])
    my_courses = [c for c in all_courses if c["id"] in course_ids]

    # Assignments this mentor has created
    all_assignments = dm.get_all("assignments")
    my_assignments = [a for a in all_assignments if a.get("mentor_id") == user_id]

    # Pending submissions (submitted but not graded by mentor's assigned students)
    pending_reviews = []
    for assignment in my_assignments:
        for submission in assignment.get("submissions", []):
            if submission.get("status") != "graded":
                pending_reviews.append({
                    "assignment_title": assignment["title"],
                    "student_id": submission["student_id"],
                    "submitted_at": submission["submitted_at"],
                })

    # Notifications for this mentor
    all_notifications = dm.get_all("notifications")
    my_notifications = [n for n in all_notifications if n.get("user_id") == user_id]
    unread_count = sum(1 for n in my_notifications if not n.get("read", True))

    # Announcements
    announcements = [
        a for a in dm.get_all("announcements")
        if "mentor" in a.get("target_roles", [])
    ]

    # Dashboard/chart data
    dashboard_data = dm.find_one("dashboard", {}) or {}

    # Build student progress summary for charts
    student_names = [s["name"].split()[0] for s in my_students]
    student_progress = [s.get("overall_progress", 0) for s in my_students]

    return render_template(
        "mentor/dashboard.html",
        mentor=mentor,
        my_students=my_students,
        my_courses=my_courses,
        my_assignments=my_assignments,
        pending_reviews=pending_reviews,
        notifications=my_notifications,
        unread_count=unread_count,
        announcements=announcements[:3],
        dashboard_data=dashboard_data,
        student_names=student_names,
        student_progress=student_progress,
    )


@mentor_bp.route("/assignment/create", methods=["POST"])
@mentor_required
def create_assignment():
    """Create a new assignment (AJAX)."""
    user_id = session.get("user_id")
    data = request.get_json()
    assignment = {
        "title": data.get("title"),
        "description": data.get("description"),
        "course_id": data.get("course_id"),
        "due_date": data.get("due_date"),
        "max_score": int(data.get("max_score", 100)),
        "difficulty": data.get("difficulty", "Medium"),
        "type": data.get("type", "Assignment"),
        "mentor_id": user_id,
        "assigned_to": data.get("assigned_to", []),
        "status": "active",
        "submissions": [],
    }
    result = dm.create("assignments", assignment)
    return jsonify({"success": True, "assignment": result})
