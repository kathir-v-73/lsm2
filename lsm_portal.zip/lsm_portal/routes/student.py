"""
Prime Vector LSM Portal – Student Routes
All protected routes for the student dashboard.
"""

from flask import Blueprint, render_template, session, jsonify, request
from pathlib import Path
from utils.data_manager import DataManager
from routes.auth import student_required

student_bp = Blueprint("student", __name__, url_prefix="/student")

_BASE = Path(__file__).resolve().parent.parent
dm = DataManager(_BASE / "data")


@student_bp.route("/dashboard")
@student_required
def dashboard():
    """Main student dashboard – loads all data for the logged-in student."""
    user_id = session.get("user_id")

    # Fetch student profile
    student = dm.get_by_id("students", user_id)
    if not student:
        return "Student not found", 404

    # Fetch all courses and filter enrolled ones
    all_courses = dm.get_all("courses")
    enrolled_ids = student.get("courses_enrolled", [])
    enrolled_courses = [c for c in all_courses if c["id"] in enrolled_ids]

    # Fetch assignments for this student
    all_assignments = dm.get_all("assignments")
    my_assignments = [a for a in all_assignments if user_id in a.get("assigned_to", [])]

    # Fetch notifications for this student
    all_notifications = dm.get_all("notifications")
    my_notifications = [n for n in all_notifications if n.get("user_id") == user_id]
    unread_count = sum(1 for n in my_notifications if not n.get("read", True))

    # Fetch announcements (target student or all)
    announcements = [
        a for a in dm.get_all("announcements")
        if "student" in a.get("target_roles", [])
    ]

    # Dashboard statistics JSON for charts
    dashboard_data = dm.find_one("dashboard", {}) or {}

    # Progress data per course (simulated from student's overall_progress)
    course_progress = {}
    for course in enrolled_courses:
        # Simulate per-course progress spread around overall
        import random
        random.seed(hash(user_id + course["id"]))
        variance = random.randint(-15, 15)
        prog = min(100, max(0, student.get("overall_progress", 50) + variance))
        course_progress[course["id"]] = prog

    return render_template(
        "student/dashboard.html",
        student=student,
        enrolled_courses=enrolled_courses,
        course_progress=course_progress,
        assignments=my_assignments,
        notifications=my_notifications,
        unread_count=unread_count,
        announcements=announcements[:3],
        dashboard_data=dashboard_data,
    )


@student_bp.route("/notifications/mark-read", methods=["POST"])
@student_required
def mark_notifications_read():
    """Mark all notifications as read for this student (AJAX)."""
    user_id = session.get("user_id")
    all_notifications = dm.get_all("notifications")
    for n in all_notifications:
        if n.get("user_id") == user_id:
            n["read"] = True
    dm._write("notifications", all_notifications)
    return jsonify({"success": True})


@student_bp.route("/profile/update", methods=["POST"])
@student_required
def update_profile():
    """Update student profile fields (AJAX)."""
    user_id = session.get("user_id")
    data = request.get_json()
    allowed_fields = ["phone", "bio", "linkedin", "location"]
    updates = {k: v for k, v in data.items() if k in allowed_fields}
    result = dm.update("students", user_id, updates)
    if result:
        return jsonify({"success": True, "message": "Profile updated successfully!"})
    return jsonify({"success": False, "message": "Update failed."})
