/**
 * Prime Vector LSM Portal – Mentor Dashboard JavaScript
 * mentor.js
 */

document.addEventListener('DOMContentLoaded', function () {

  /* Student Progress Bar Chart (Overview) */
  const spCtx = document.getElementById('studentProgressChart');
  if (spCtx && typeof MENTOR_DATA !== 'undefined') {
    new Chart(spCtx, {
      type: 'bar',
      data: {
        labels: MENTOR_DATA.studentNames,
        datasets: [{
          label: 'Progress %',
          data: MENTOR_DATA.studentProgress,
          backgroundColor: MENTOR_DATA.studentProgress.map(p =>
            p >= 75 ? 'rgba(34,197,94,0.85)' :
            p >= 50 ? 'rgba(99,102,241,0.85)' : 'rgba(245,158,11,0.85)'
          ),
          borderRadius: 8,
          borderSkipped: false,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#9ca3af', font: { size: 11 } } },
          y: { min: 0, max: 100, ticks: { callback: v => `${v}%`, color: '#9ca3af', font: { size: 11 } }, grid: { color: 'rgba(0,0,0,0.04)' } },
        },
      },
    });
  }

  /* Mentor Progress Chart (Progress section) */
  const mpCtx = document.getElementById('mentorProgressChart');
  if (mpCtx && typeof MENTOR_DATA !== 'undefined') {
    new Chart(mpCtx, {
      type: 'radar',
      data: {
        labels: MENTOR_DATA.studentNames,
        datasets: [{
          label: 'Progress %',
          data: MENTOR_DATA.studentProgress,
          fill: true,
          backgroundColor: 'rgba(139,92,246,0.15)',
          borderColor: 'rgba(139,92,246,0.8)',
          pointBackgroundColor: 'rgba(139,92,246,1)',
          borderWidth: 2,
        }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          r: {
            min: 0, max: 100,
            ticks: { callback: v => `${v}%`, font: { size: 10 }, color: '#9ca3af', stepSize: 25 },
            grid: { color: 'rgba(0,0,0,0.06)' },
            pointLabels: { font: { size: 11 }, color: '#6b7280' },
          },
        },
      },
    });
  }
});
