"""
Prime Vector LSM Portal – Routes Package
"""
